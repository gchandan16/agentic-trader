import ccxt
import os
from dotenv import load_dotenv

load_dotenv()

api = os.getenv("DELTA_API_KEY")
secret = os.getenv("DELTA_SECRET_KEY")

print("API:", api)

exchange = ccxt.delta({
    "apiKey": api,
    "secret": secret
})

balance = exchange.fetch_balance()

print(balance)